
package laboratorio_2_fernando_calvo_picado;
import java.util.Scanner;

public class ejercicio_1 {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        //variables
        int examResult = 0;
        
        while (true) {            
            
        }       
    } 
}
